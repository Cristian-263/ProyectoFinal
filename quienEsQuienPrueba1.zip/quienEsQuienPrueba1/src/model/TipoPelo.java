package model;

public enum TipoPelo {
	CORTO,
	LARGO,
	RIZADO,
	CALVO,
	CRESTA;
	

}
