package model;

public enum ColorPelo {
	RUBIO,
	MORENO,
	CASTANYO,
	BLANCO,
	PELIRROJO;

}
