package model;

public enum Genero {
	HOMBRE,
	MUJER;
	

}
