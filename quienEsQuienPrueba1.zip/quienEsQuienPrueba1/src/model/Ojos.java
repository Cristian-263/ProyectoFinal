package model;

public enum Ojos {
	MARRONES,
	NEGROS,
	AZULES,
	VERDES;

}
